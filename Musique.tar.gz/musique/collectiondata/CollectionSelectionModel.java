package musique.collectiondata;

import musique.Model;
import musique.loaders.ReleaseLoader;
import java.util.List;
import java.util.ArrayList;

/** A model that holds the currently selected release
 *  in the collection.
 */
public class CollectionSelectionModel extends Model
{
    /** The currently selected release - can be null. */
    private Release selection;

    /** Constructor.
     */
    public CollectionSelectionModel()
    {
        this.selection = null;
    }

    /** Ask for the currently selected object.
     *  @return The currently selected release.
     */
    public Release getSelection()
    {
        return selection;
    }

    /** Sets the selection.
     *  @param selection The new Release selection for this collection.
     */
    public void setSelection( Release selection )
    {
        if( this.selection != selection ) {
            this.selection = selection;
            fireStateChanged();

            /* Load the selection quickly if it hasn't been loaded yet. */
            if( selection != null && !selection.isLoaded() ) {
                ReleaseLoader releaseLoader = new ReleaseLoader( selection );
                releaseLoader.loadInBackground();
            }
        }
    }
}
