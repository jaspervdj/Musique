package musique.visualisations;

import musique.collectiondata.Release;
import musique.resources.ResourceManager;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/** A static class that is used to get icons for
 *  various release formats.
 */
public class ReleaseIconManager
{
    /** The format names. */
    private static final String[] formats = { "cd", "vinyl", "cassette" };

    /** Regexes to determine the formats. These regexes should match
     *  the {@code} formats array. */
    private static final String[] regexes = { ".*cd.*", ".*(vinyl)|(lp)|(12\").*", ".*(cassette)|(k7).*" };

    /** An array containing the actual icons. */
    private static final Icon[] icons;

    /** An icon for unknown release formats. */
    private static final Icon unknownIcon;

    /** Loads an icon from the images folder.
     *  @param name Basename without extension of the image.
     *  @return The loaded image.
     */

    /* Load in all the icons. */
    static
    {
        icons = new Icon[formats.length];
        for( int i=0; i<icons.length; i++ )
            icons[i] = ResourceManager.getIcon( formats[i] );

        unknownIcon = ResourceManager.getIcon("unknown");
    }

    /** Get an icon for a certain release.
     *  @param release Release to get an icon for.
     *  @return An icon that matches the release.
     */
    public static Icon getReleaseIcon( Release release )
    {
        String format = release.getFormat().toLowerCase();

        int index = 0;
        while( index<regexes.length && !format.matches(regexes[index]) )
            index++;

        if( index >= regexes.length )
            return unknownIcon;
        else
            return icons[index];
    }
}
