package musique.visualisations;

import musique.collectiondata.Release;
import musique.resources.ResourceManager;
import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.ImageIcon;
import javax.swing.Icon;

/** A Browser with which the user can select a release.
 */
public class CoverVisualisationReleaseBrowser extends CoverVisualisationBrowser
{
    /** Constructor.
     *  @param model CoverVisualisationModel to browse.
     */
    public CoverVisualisationReleaseBrowser( CoverVisualisationModel model )
    {
        super( model );

        Release release = model.getRelease();
        if( release != null ) {
            label.setText( release.getTitle() );
            label.setIcon( ReleaseIconManager.getReleaseIcon( release ) );
        }
    }

    @Override
    public ActionListener createPreviousActionListener()
    {
        return new ActionListener() {
            public void actionPerformed( ActionEvent event ) {
                model.previousRelease();
            }
        };
    }

    @Override
    public ActionListener createNextActionListener()
    {
        return new ActionListener() {
            public void actionPerformed( ActionEvent event ) {
                model.nextRelease();
            }
        };
    }

    @Override
    public void stateChanged( ChangeEvent event )
    {
        previous.setEnabled( model.getCurrentRelease() > 0 );

        Release release = model.getRelease();
        if( release != null ) {
            label.setText( release.getTitle() );
            label.setIcon( ReleaseIconManager.getReleaseIcon( release ) );
        }
        
        next.setEnabled( model.getCurrentRelease() + 1 < model.getNumberOfReleases() );
    }
}
