package musique.visualisations;

import musique.resources.I18nManager;
import musique.collectiondata.CollectionDataModel;

public class TreeVisualisationFactory implements VisualisationFactory
{
    @Override
    public String getName()
    {
        return I18nManager.getMessage("tree");
    }

    @Override
    public Visualisation createVisualisation( CollectionDataModel dataModel )
    {
        return new TreeVisualisation( dataModel );
    }
}
