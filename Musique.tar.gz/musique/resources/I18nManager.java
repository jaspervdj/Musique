package musique.resources;

import java.util.ResourceBundle;
import java.util.Locale;
import java.text.MessageFormat;

/** A class responsible for the internationalization
 *  of messages.
 */
public class I18nManager
{
    /** The ResourceBundle. */
    public static final Locale locale = Locale.getDefault();
    private static final ResourceBundle resourceBundle = ResourceBundle.getBundle("musique.resources.MessageBundle", locale );

    /** Get a simple message.
     *  @param key The message key.
     *  @return The message in the correct Locale.
     */
    public static String getMessage( String key )
    {
        return resourceBundle.getString( key );
    }

    /** Get a not so simple message.
     *  @param key The message key.
     *  @param arguments The message arguments to be given to the key.
     *  @return The message in the correct Locale.
     */
    public static String getMessage( String key, Object[] arguments )
    {
        return MessageFormat.format( getMessage(key), arguments );
    }
}
