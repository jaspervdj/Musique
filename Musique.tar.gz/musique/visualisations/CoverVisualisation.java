package musique.visualisations;

import musique.collectiondata.CollectionDataModel;
import java.awt.EventQueue;
import java.awt.BorderLayout;

/** A Visualisation that lets the user browse covers.
 *  This is a container containing various panels to
 *  browse the covers.
 */
public class CoverVisualisation extends Visualisation
{
    private CoverVisualisationModel model;
    private CoverVisualisationView view;
    private CoverVisualisationBrowser yearBrowser, releaseBrowser;

    /** Constructor
     *  @param dataModel CollectionDataModel to be visualised.
     */
    public CoverVisualisation( CollectionDataModel dataModel )
    {
        super( dataModel );
        model = new CoverVisualisationModel( dataModel );

        setLayout( new BorderLayout() );

        yearBrowser = new CoverVisualisationYearBrowser( model );
        add( yearBrowser, BorderLayout.NORTH );

        view = new CoverVisualisationView( model );
        add( view, BorderLayout.CENTER );

        releaseBrowser = new CoverVisualisationReleaseBrowser( model );
        add( releaseBrowser, BorderLayout.SOUTH );
    }
}
