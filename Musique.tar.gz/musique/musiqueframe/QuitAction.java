package musique.musiqueframe;

import musique.resources.I18nManager;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.AbstractAction;
import javax.swing.KeyStroke;

/** An Action that closes a frame.
 */
public class QuitAction extends AbstractAction
{
    private MusiqueFrame frame;

    /** Constructor.
     *  @param frame Frame to close when the action is used.
     */
    public QuitAction( MusiqueFrame frame )
    {
        super( I18nManager.getMessage("quit"));
        putValue( MNEMONIC_KEY, KeyEvent.VK_Q );
        putValue( ACCELERATOR_KEY, KeyStroke.getKeyStroke( "ctrl Q" ) );

        this.frame = frame;
    }

    /** Called when the action is used. Close the frame.
     *  @param event Data about the event.
     */
    public void actionPerformed( ActionEvent event )
    {
        EventQueue.invokeLater( new Runnable() {
            public void run() {
                frame.dispose();
                System.exit(0);
            }
        } );
    }
}
