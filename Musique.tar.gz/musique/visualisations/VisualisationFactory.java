package musique.visualisations;

import musique.collectiondata.CollectionDataModel;

/** Factory used to create visualisations.
 */
interface VisualisationFactory
{
    /** Gets a name for the visualisation.
     *  @return The name of the visualisation.
     */
    public String getName();

    /** Creates a new visualisation.
     *  @param dataModel CollectionDataModel to be used for the Visualisation.
     *  @return A new Visualisation.
     */
    public Visualisation createVisualisation( CollectionDataModel dataModel );
}
