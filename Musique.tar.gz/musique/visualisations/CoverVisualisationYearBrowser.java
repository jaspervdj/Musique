package musique.visualisations;

import musique.collectiondata.Release;
import musique.resources.ResourceManager;
import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.ImageIcon;
import javax.swing.Icon;

/** A Browser with which the user can select a year.
 */
public class CoverVisualisationYearBrowser extends CoverVisualisationBrowser
{
    /** Constructor.
     *  @param model CoverVisualisationModel to browse.
     */
    public CoverVisualisationYearBrowser( CoverVisualisationModel model )
    {
        super( model );

        Release release = model.getRelease();
        if( release != null )
            label.setText( release.getYear() );
    }

    @Override
    public ActionListener createPreviousActionListener()
    {
        return new ActionListener() {
            public void actionPerformed( ActionEvent event ) {
                model.previousYear();
            }
        };
    }

    @Override
    public ActionListener createNextActionListener()
    {
        return new ActionListener() {
            public void actionPerformed( ActionEvent event ) {
                model.nextYear();
            }
        };
    }

    @Override
    public void stateChanged( ChangeEvent event )
    {
        previous.setEnabled( model.getCurrentYear() > 0 );

        Release release = model.getRelease();
        if( release != null )
            label.setText( release.getYear() );
        
        next.setEnabled( model.getCurrentYear() + 1 < model.getNumberOfYears() );
    }
}
