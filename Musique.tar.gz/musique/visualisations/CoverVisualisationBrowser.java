package musique.visualisations;

import musique.collectiondata.Release;
import musique.resources.ResourceManager;
import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.ImageIcon;
import javax.swing.Icon;

/** A panel with a label, and a next and previous button,
 *  so the user can browse through items.
 */
public abstract class CoverVisualisationBrowser extends JPanel implements ChangeListener
{
    protected CoverVisualisationModel model;
    protected JButton previous, next;
    protected JLabel label;

    /** Constructor.
     *  @param model CoverVisualisationModel to browse.
     */
    public CoverVisualisationBrowser( CoverVisualisationModel model )
    {
        super( new BorderLayout() );
        this.model = model;

        previous = new JButton();
        previous.setIcon( ResourceManager.getIcon("previous") );
        add( previous, BorderLayout.WEST );

        previous.addActionListener( createPreviousActionListener() );

        label = new JLabel();
        label.setHorizontalAlignment( JLabel.CENTER );
        add( label, BorderLayout.CENTER );

        next = new JButton();
        next.setIcon( ResourceManager.getIcon("next") );
        add( next, BorderLayout.EAST );

        next.addActionListener( createNextActionListener() );

        model.addChangeListener( this );
    }

    /** Create an ActionListener to respond to the event
     *  generated when the user clicks the previous button.
     *  @return An appropriate ActionListener.
     */
    public abstract ActionListener createPreviousActionListener();

    /** Create an ActionListener to respond to the event
     *  generated when the user clicks the next button.
     *  @return An appropriate ActionListener.
     */
    public abstract ActionListener createNextActionListener();
}
