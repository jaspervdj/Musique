package musique.loaders;

import musique.Model;

/** An abstract class used to load data. The sort
 *  of data is determined by which subclass you
 *  are using. Every Loader contains two important
 *  functions: loadInBackground and loadInForeground().
 *  They have the same result but are non-blocking
 *  and blocking, repectively.
 */
public abstract class Loader extends Model implements Runnable
{
    /** This will load the data in the background
     *  by starting a new Thread behind the scenes.
     *  Therefore, this is non-blocking call.
     */
    public void loadInBackground()
    {
        Thread thread = new Thread( this );
        thread.start();
    }

    /** This will load the data in the foreground,
     *  aka the current Thread. That's why this is
     *  a blocking call.
     */
    public void loadInForeground()
    {
        if( !isDone() ) {
            load();
            fireStateChanged();
        }
    }

    /** The Thread function that needs to overwritten.
     */
    @Override
    public void run()
    {
        loadInForeground();
    }

    /** An internally used function. Use loadInBackground()
     *  or loadInForeground() instead.
     */
    public abstract void load();

    /** See if the subject is already completely loaded.
     *  @return {@code true} if we're done loading.
     */
    public abstract boolean isDone();
}
