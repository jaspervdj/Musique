package musique.visualisations;

import musique.resources.I18nManager;
import musique.collectiondata.CollectionDataModel;

public class CoverVisualisationFactory implements VisualisationFactory
{
    @Override
    public String getName()
    {
        return I18nManager.getMessage("covers");
    }

    @Override
    public Visualisation createVisualisation( CollectionDataModel dataModel )
    {
        return new CoverVisualisation( dataModel );
    }
}
