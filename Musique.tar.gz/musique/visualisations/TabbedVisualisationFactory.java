package musique.visualisations;

import musique.collectiondata.CollectionDataModel;
import musique.resources.I18nManager;

public class TabbedVisualisationFactory implements VisualisationFactory
{
    @Override
    public String getName()
    {
        return I18nManager.getMessage("tabs");
    }

    @Override
    public Visualisation createVisualisation( CollectionDataModel dataModel )
    {
        return new TabbedVisualisation( dataModel );
    }
}
