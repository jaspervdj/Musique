package musique.loaders;

import musique.collectiondata.Collection;
import musique.collectiondata.Release;
import musique.resources.I18nManager;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import java.io.IOException;
import java.util.List;

/** An {@link XMLLoader} user to load various collection
 *  types.
 */
public abstract class CollectionLoader extends DiscogsXMLLoader
{
    /** The Collection we are dealing with. */
    private Collection collection;

    /** Constructor.
     *  @param collection The Collection to start loading.
     */
    public CollectionLoader( Collection collection )
    {
        super( collection );
        this.collection = collection;
    }

    /** Get the associated Collection.
     *  @return The collection we are loading.
     */
    public Collection getCollection()
    {
        return collection;
    }

    /** Loads all collection data for the collection.
     */
    @Override
    public void load()
    {
        /* Load the Document. */
        super.load();

        /* Get the main element. */
        if( getDocument() != null ) {
            Element main = getMainElement();

            /* Extract information. */
            if( main != null ) {
                collection.setName( loadName( main ) );
                collection.setInformation( loadInformation( main ) );
                collection.setImageURL( loadImageURL(main) );
                fetchReleases( main );
            }
        }

        collection.setLoaded( true );
    }

    /** Load the Collection name from an element
     *  @param main Element that contains a name element.
     *  @return The name, or null if not found.
     */
    public String loadName( Element main )
    {
        Element name = main.getChild( "name" );
        if( name != null )
            return name.getTextNormalize();
        else
            return I18nManager.getMessage("no_name");
    }

    /** Load the Collection information from an element. The
     *  information is searched for in a {@code <profile>}
     *  element. If this is not the case, override this function.
     *  @param main Element that contains a information element.
     *  @return The information, or null if not found.
     */
    public String loadInformation( Element main )
    {
        Element information = main.getChild( "profile" );
        if( information != null )
            return information.getTextNormalize();
        else
            return I18nManager.getMessage("no_information");
    }

    /** Load all the releases in this collection, and add
     *  them to the collection.
     *  @param main Element that contains a {@code <releases>} element.
     */
    public void fetchReleases( Element main )
    {
        Element releases = main.getChild( "releases" );

        if( releases != null ) {
            List list = releases.getChildren( "release" );
            for( Object object: list ) {
                Element element = (Element) object;
                String id = element.getAttributeValue("id");
                Release release = new Release( Integer.parseInt(id) );

                Element title = element.getChild("title");
                if( title != null )
                    release.setTitle( title.getTextNormalize() );

                /* If we are lucky, the year is already present in this file. */
                Element year = element.getChild("year");
                if( year != null )
                    release.setYear( year.getTextNormalize() );

                Element format = element.getChild("format");
                if( format != null )
                    release.setFormat( format.getTextNormalize() );

                Element artist = element.getChild("artist");
                if( artist != null )
                    release.setArtist( artist.getTextNormalize() );

                Element label = element.getChild("label");
                if( label != null )
                    release.setArtist( label.getTextNormalize() );

                collection.getDataModel().addRelease( release );
            }
        }

        for( Release release: collection.getDataModel().getAllReleases() ) {
            /* Create a ReleaseLoader to further load the release. */
            ReleaseLoader releaseLoader = new ReleaseLoader( release );
            //releaseLoader.loadInBackground();
            releaseLoader.loadInForeground();
        }

    }
}
