package musique.collectionframe;

import musique.collectiondata.Collection;
import musique.resources.I18nManager;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.KeyStroke;
import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

/** An action that can rename a Collection when performed.
 */
public class RenameCollectionAction extends AbstractAction
{
    private CollectionFrame collectionFrame;

    /** Constructor.
     *  @param CollectionFrame Frame of the to be renamed collection.
     */
    public RenameCollectionAction( CollectionFrame collectionFrame )
    {
        super( I18nManager.getMessage("rename") );
        putValue( MNEMONIC_KEY, KeyEvent.VK_N );
        putValue( ACCELERATOR_KEY, KeyStroke.getKeyStroke( "ctrl r" ) );

        this.collectionFrame = collectionFrame;
    }

    /** Called when an action is performed. Show a dialog to the
     *  user that allows him to edit the Collection name.
     */
    @Override
    public void actionPerformed( ActionEvent event )
    {
        Collection collection = collectionFrame.getCollection();
        String name = JOptionPane.showInputDialog( collectionFrame, "Rename the collection:", collection.getName() );
        if( name != null && name.length() != 0 ) {
            collection.setName( name );
        }
    }
}
