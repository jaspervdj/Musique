package musique.musiqueframe;

import musique.visualisations.VisualisationSelectionModel;
import musique.resources.I18nManager;
import java.awt.event.KeyEvent;
import javax.swing.JMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ButtonGroup;
import javax.swing.AbstractAction;

/** A menu containing settings.
 */
public class SettingsMenu extends JMenu
{
    /** Constructor.
     */
    public SettingsMenu( VisualisationSelectionModel visualisationSelectionModel )
    {
        super( I18nManager.getMessage("settings") );
        setMnemonic( KeyEvent.VK_S );

        ButtonGroup group = new ButtonGroup();
        for( int i=0; i<visualisationSelectionModel.getNumberOfVisualisations(); i++ ) {
            JRadioButtonMenuItem radioButton = new JRadioButtonMenuItem( new SelectVisualisationAction( visualisationSelectionModel, i ) );
            group.add( radioButton );
            add( radioButton );

            if( i == visualisationSelectionModel.getVisualisation() )
                radioButton.setSelected( true );
        }        
    }
}
