package musique.loaders;

import musique.Model;

/** This class represents something that can be loaded.
 *  It is, therefore, associated with a Loader.
 */
public abstract class Loadable extends Model
{
    /** Loader assigned to load this object. */
    private Loader loader;

    /** The load status. */
    private boolean loaded;

    /** Flag indicating if this object is valid -
     *  if it is not valid, it should be closed
     *  or thrown away. */
    private boolean valid;

    /** Constructor.
     */
    public Loadable()
    {
        loader = null;
        loaded = false;
        valid = true;
    }

    /** Set the loader for this object. The Loader
     *  should do that himself.
     *  @param loader The Loader that is loading this object.
     */
    public void setLoader( Loader loader )
    {
        this.loader = loader;
    }

    /** Fetch the Loader that is loading this object.
     *  @return The Loader that is loading this object.
     */
    public Loader getLoader()
    {
        return loader;
    }

    /** See if this object is completely loaded.
     *  @return {@code true} is this object is completely loaded.
     */
    public boolean isLoaded()
    {
        return loaded;
    }

    /** Set the load status for this object.
     *  @param loaded If this object is loaded.
     */
    public void setLoaded( boolean loaded )
    {
        this.loaded = loaded;
    }

    /** Check if this object is valid. When it is
     *  not valid, you should close it.
     *  @return If this object is still valid.
     */
    public boolean isValid()
    {
        return valid;
    }

    /** Set the valid flag for this object.
     *  @param valid If this object is still valid.
     */
    public void setValid( boolean valid )
    {
        if( valid != this.valid ) {
            this.valid = valid;
            fireStateChanged();
        }
    }
}
