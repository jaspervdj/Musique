package musique.resources;

import java.net.URL;
import javax.swing.ImageIcon;

/** A simple class with static methods to obtain resources
 *  from the class path.
 */
public class ResourceManager
{
    /** Convert a fileName to an URL. The fileName should be relative
     *  to the resources directory.
     *  @param fileName File to look for.
     *  @return The URL of the file.
     */
    public static URL getResource( String fileName )
    {
        return ResourceManager.class.getResource( "/musique/resources/" + fileName );
    }

    /** Construct an ImageIcon from a fileName.
     *  @param fileName The basename of the file, without the ".png" extension.
     *  @return An ImageIcon with the given image.
     */
    public static ImageIcon getIcon( String fileName )
    {
        return new ImageIcon( getResource( fileName + ".png" ) );
    }
}
