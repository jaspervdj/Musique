package musique.musiqueframe;

import musique.visualisations.VisualisationSelectionModel;
import musique.resources.ResourceManager;
import musique.resources.I18nManager;
import java.awt.EventQueue;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ButtonGroup;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** The main window for the Musique application.
 */
public class MusiqueFrame extends JFrame
{
    private VisualisationSelectionModel visualisationSelectionModel;
    private FrameListModel frameListModel;

    /** Constructor.
     */
    public MusiqueFrame()
    {
        super("Musique");
        visualisationSelectionModel = new VisualisationSelectionModel();
        frameListModel = new FrameListModel();

        AbstractAction openArtistAction = new OpenArtistAction( this );
        AbstractAction openLabelAction = new OpenLabelAction( this );
        AbstractAction openCustomAction = new OpenCustomAction( this );
        AbstractAction openNewAction = new OpenNewAction( this );

        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu( I18nManager.getMessage("file") );
        fileMenu.setMnemonic( KeyEvent.VK_F );

        fileMenu.add( openArtistAction );
        fileMenu.add( openLabelAction );
        fileMenu.addSeparator();
        fileMenu.add( openCustomAction );
        fileMenu.add( openNewAction );
        fileMenu.addSeparator();
        fileMenu.add( new QuitAction(this) );

        menuBar.add( fileMenu );

        JMenu settingsMenu = new SettingsMenu( visualisationSelectionModel );
        menuBar.add( settingsMenu );

        JMenu framesMenu = new FramesMenu( frameListModel );
        menuBar.add( framesMenu );

        setJMenuBar( menuBar );

        setLayout( new BorderLayout() );
        Container container = getContentPane();
        container.add( new JLabel( ResourceManager.getIcon("musique") ), BorderLayout.NORTH );
        JPanel bottom = new JPanel( );
        bottom.add( new JButton( openArtistAction ) );
        bottom.add( new JButton( openLabelAction ) );
        container.add( bottom, BorderLayout.SOUTH );

        pack();
        setDefaultCloseOperation( JFrame.DO_NOTHING_ON_CLOSE );
        setVisible( true );
        addWindowListener( new WindowAdapter() {
            public void windowClosing( WindowEvent event ) {
                if( frameListModel.requestDispose() )
                    System.exit( 0 );
            }
        } );
    }

    /** Get the VisualisationSelectionModel for this frame.
     *  @return The associated VisualisationSelectionModel.
     */
    public VisualisationSelectionModel getVisualisationSelectionModel()
    {
        return visualisationSelectionModel;
    }

    /** Get the FrameListModel for this frame.
     *  @return The associated FrameListModel.
     */
    public FrameListModel getFrameListModel()
    {
        return frameListModel;
    }
}
