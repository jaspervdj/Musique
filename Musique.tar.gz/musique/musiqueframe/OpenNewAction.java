package musique.musiqueframe;

import musique.resources.I18nManager;
import musique.collectionframe.CollectionFrame;
import musique.collectiondata.Collection;
import musique.collectionframe.CustomCollectionFrame;
import musique.loaders.CollectionLoader;
import musique.loaders.NewCollectionLoader;
import java.awt.event.KeyEvent;
import javax.swing.KeyStroke;

/** An action used to open a new CollectionFrame
 *  about an custom collection.
 */
public class OpenNewAction extends OpenAction
{
    /** Constructor.
     *  @param musiqueFrame Main MusiqueFrame instance.
     */
    public OpenNewAction( MusiqueFrame musiqueFrame )
    {
        super( musiqueFrame, I18nManager.getMessage("new_collection") );
        putValue( MNEMONIC_KEY, KeyEvent.VK_N );
        putValue( ACCELERATOR_KEY, KeyStroke.getKeyStroke( "ctrl N" ) );
    }

    /** Get a loader for the collection.
     *  @param collection Collection to create the loader for.
     *  @return A fitting CollectionLoader.
     */
    public CollectionLoader createCollectionLoader( Collection collection )
    {
        return new NewCollectionLoader( collection );
    }

    @Override
    public CollectionFrame createCollectionFrame( MusiqueFrame musiqueFrame, Collection collection )
    {
        return new CustomCollectionFrame( musiqueFrame, collection );
    }
}
