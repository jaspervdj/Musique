package musique.musiqueframe;

import musique.resources.I18nManager;
import musique.collectiondata.Collection;
import musique.loaders.CollectionLoader;
import musique.loaders.LabelCollectionLoader;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

/** An action used to open a new CollectionFrame
 *  about a label.
 */
public class OpenLabelAction extends OpenAction
{
    /** Constructor.
     *  @param musiqueFrame Main MusiqueFrame instance.
     */
    public OpenLabelAction( MusiqueFrame musiqueFrame )
    {
        super( musiqueFrame, I18nManager.getMessage("open_label") );
        putValue( MNEMONIC_KEY, KeyEvent.VK_L );
    }

    /** Get a loader for the collection.
     *  @param collection Collection to create the loader for.
     *  @return A fitting CollectionLoader.
     */
    @Override
    public CollectionLoader createCollectionLoader( Collection collection )
    {
        String label = JOptionPane.showInputDialog( getMusiqueFrame(),
                                                    I18nManager.getMessage("prompt_label"),
                                                    "silken tofu" );
        if( label != null )
            return new LabelCollectionLoader( collection, label );
        else
            return null;
    }
}
